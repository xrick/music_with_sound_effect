## VST3 C API

This repository contains the VST3 C API. 

The VST3 C API has the same dual license as the VST3 C++ API, check the LICENSE.txt before using!

It is automatically generated out of the C++ VST3 API (See https://github.com/steinbergmedia/vst3_c_api_generator)

To learn more about VST3 check out https://steinbergmedia.github.io/vst3_dev_portal/

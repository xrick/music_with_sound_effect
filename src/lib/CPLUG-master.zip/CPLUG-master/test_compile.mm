#include "test_compile.cpp"
#include "example/example.m"

#include "cplug_standalone_osx.m"